 <?php $page_heading = "Service Provider Profile";?>
 <?php include 'header.php' ;?>
 <?php include 'service_provider_menu.php' ;?>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="category_wise_service">
					<h3 style="text-align: center; color: #5d5d5d">Service Provider Name</h3>
				<div class="service_add">
					<div class="col-md-1 no-padding srv_arrow">
						<i class="fa fa-arrow-circle-down" aria-hidden="true"></i>
					</div>
					<div class="col-md-8 no-padding">
						<h4>Service Provider Name</h4>
						<p>Service Description goes here</p>
					</div>
					<div class="col-md-3">
						<a href="" class="btn btn-default src_add_btn">Add</a>
					</div>
					<div style="clear: both;"></div>
				</div>
				<div class="service_add">
					<div class="col-md-1 no-padding srv_arrow">
						<i class="fa fa-arrow-circle-down" aria-hidden="true"></i>
					</div>
					<div class="col-md-8 no-padding">
						<h4>Service Provider Name</h4>
						<p>Service Description goes here</p>
					</div>
					<div class="col-md-3">
						<a href="" class="btn btn-default src_add_btn">Add</a>
					</div>
					<div style="clear: both;"></div>
				</div>
				<div class="service_add">
					<div class="col-md-1 no-padding srv_arrow">
						<i class="fa fa-arrow-circle-down" aria-hidden="true"></i>
					</div>
					<div class="col-md-8 no-padding">
						<h4>Service Provider Name</h4>
						<p>Service Description goes here</p>
					</div>
					<div class="col-md-3">
						<a href="" class="btn btn-default src_add_btn">Add</a>
					</div>
					<div style="clear: both;"></div>
				</div>
				<div class="service_add">
					<div class="col-md-1 no-padding srv_arrow">
						<i class="fa fa-arrow-circle-down" aria-hidden="true"></i>
					</div>
					<div class="col-md-8 no-padding">
						<h4>Service Provider Name</h4>
						<p>Service Description goes here</p>
					</div>
					<div class="col-md-3">
						<a href="" class="btn btn-default src_add_btn">Add</a>
					</div>
					<div style="clear: both;"></div>
				</div>
				<div class="service_add">
					<div class="col-md-1 no-padding srv_arrow">
						<i class="fa fa-arrow-circle-down" aria-hidden="true"></i>
					</div>
					<div class="col-md-8 no-padding">
						<h4>Service Provider Name</h4>
						<p>Service Description goes here</p>
					</div>
					<div class="col-md-3">
						<a href="" class="btn btn-default src_add_btn">Add</a>
					</div>
					<div style="clear: both;"></div>
				</div>

			</div>
		</div>
	</div>
</div>
<section style="background: #adacb4; margin-top: 50px;">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="category_wise_service_menu">
					<ul>
						<li><a>Details</a></li>
						<li><a>Reviews</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>

<<section class="service_description">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2>Service Description</h2>
				<div class="service_advantage">
					<h2>Advantage</h2>
					<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of cl tin literature from 45 BC, making it over 2000 years old. </p>
				</div>
				<div class="service_advantage">
					<h2>Pricing & Terms</h2>
					<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of cl tin literature from 45 BC, making it over 2000 years old. </p>
				</div>
				<h2 style="margin-top: 80px">Reviews</h2>

					<div class="reviews">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
								<img src="images/user-icon.png">
							</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
								<h3 class="sp_name">Riyad Hossein</h3>
								<div class="ratting">
							  		<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star"></span>
							  	</div>
							  	<p class="comment">He is a very good service provider. I prefer him to everyone.</p>
							  	<p class="done_by">Done By <span style="color: #424141;">Shahadat Hossain</span></p>
							</div>
						</div>
						<div style="clear:both"></div>
					</div>
					<div class="reviews">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
								<img src="images/user-icon.png">
							</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
								<h3 class="sp_name">Riyad Hossein</h3>
								<div class="ratting">
							  		<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star"></span>
							  	</div>
							  	<p class="comment">He is a very good service provider. I prefer him to everyone.</p>
							  	<p class="done_by">Done By <span style="color: #424141;">Shahadat Hossain</span></p>
							</div>
						</div>
						<div style="clear:both"></div>
					</div>
					<div class="reviews">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
								<img src="images/user-icon.png">
							</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
								<h3 class="sp_name">Riyad Hossein</h3>
								<div class="ratting">
							  		<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star"></span>
							  	</div>
							  	<p class="comment">He is a very good service provider. I prefer him to everyone.</p>
							  	<p class="done_by">Done By <span style="color: #424141;">Shahadat Hossain</span></p>
							</div>
						</div>
						<div style="clear:both"></div>
					</div>
					<div class="reviews">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
								<img src="images/user-icon.png">
							</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
								<h3 class="sp_name">Riyad Hossein</h3>
								<div class="ratting">
							  		<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star"></span>
							  	</div>
							  	<p class="comment">He is a very good service provider. I prefer him to everyone.</p>
							  	<p class="done_by">Done By <span style="color: #424141;">Shahadat Hossain</span></p>
							</div>
						</div>
						<div style="clear:both"></div>
					</div>
					<div class="reviews">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
								<img src="images/user-icon.png">
							</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
								<h3 class="sp_name">Riyad Hossein</h3>
								<div class="ratting">
							  		<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star"></span>
							  	</div>
							  	<p class="comment">He is a very good service provider. I prefer him to everyone.</p>
							  	<p class="done_by">Done By <span style="color: #424141;">Shahadat Hossain</span></p>
							</div>
						</div>
						<div style="clear:both"></div>
					</div>
			</div>
		</div>
	</div>
</section>

<section class="related_works">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h2 style="font-family: arboria-book; margin-top: 80px">Related Works</h2>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service1.png">
						<h4>Packaging Design</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service2.png">
						<h4>Business Cards</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service3.png">
						<h4>Architecture</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service5.png">
						<h4>Album Covers</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service6.png">
						<h4>Stationery</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service4.png">
						<h4>Logo Design</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service6.png">
						<h4>Stationery</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service4.png">
						<h4>Logo Design</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php include 'footer.php' ;?>