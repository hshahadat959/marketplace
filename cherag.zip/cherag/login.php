 <?php $page_heading = "Log in to Cherag";?>
 <?php include 'header.php' ;?>

<div class="container">
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="login">
				<img src="images/cheraglogo.png" class="center">
				<h3>Continue with</h3>
				<div class="social-buttons center">
                  <center>
                  		<a href="#" class="btn btn-fb"><i class="fa fa-facebook"></i> Facebook</a>
                  		<a href="#" class="btn btn-tw"><i class="fa fa-google"></i> Google</a>
                  </center>
               </div>
				<h3>-----Or-----</h3>
				<h3>Log in with email address</h3>
				<form action="">
				  <div class="form-group col-lg-4 col-md-4 col-lg-offset-4 col-md-offset-4">
				    <input type="email" class="form-control" id="email" placeholder="Enter email">
				  </div>
				  <div class="form-group col-lg-4 col-md-4 col-lg-offset-4 col-md-offset-4">
				    <input type="password" class="form-control" id="password" placeholder="Enter password">
				    <a href="" style="float: right;color: #403f3f;">Forgot password?</a>
				  </div>
				  <div class="col-lg-4 col-md-4 col-lg-offset-4 col-md-offset-4">
				  	<button type="submit" class="btn btn-default login-btn">Login</button>
				  	<span style="color: #6c6c6e;">New to <a href="" style="color: #403f3f; font-size: 15px;">Cherag</a>? <a href="" style="color: #403f3f; text-decoration: underline;">Create account</a>  now!</span>
				  </div>
				</form>
				<div style="clear: both;"></div>
			</div>
		</div>
	</div>	
</div>


 <?php include 'footer.php' ;?>


