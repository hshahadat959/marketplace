 <section class="footer_top">
      <div class="container">
          <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-1 col-md-offset-1">
                  <h2>Cherag</h2>
                  <ul>
                    <li><a href="about_us.php">About Us</a></li>
                    <li><a href="">Career</a></li>
                    <li><a href="">Terms & Conditions</a></li>
                    <li><a href="">Privacy Policy</a></li>
                  </ul>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-1 col-md-offset-1">
                  <h2>Resources</h2>
                  <ul>
                    <li><a href="">Customer Support</a></li>
                    <li><a href="">Hiring Headquaters</a></li>
                    <li><a href="">Hiring Resources</a></li>
                    <li><a href="">Other Services</a></li>
                  </ul>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-1 col-md-offset-1">
                  <h2>Scroll</h2>
                  <ul>
                    <li><a href="">About Cherag</a></li>
                    <li><a href="">Career</a></li>
                    <li><a href="">Security</a></li>
                    <li><a href="">Boundaries</a></li>
                  </ul>
                </div>
              </div>
          </div>
      </div>
  </section>
  
    <section class="footer_middle">
      <div class="container">
          <div class="row">
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-lg-offset-8 col-md-offset-8">
                  <h3> Cherag App Available Now!</h3>
                  <a href=""><img src="images/app_store.png"></a><a href=""><img src="images/playstore.png"></a>
              </div>
          </div>
      </div>
  </section>
  <section class="footer_bottom">
      <p>&copy; 2019 cherag.com.bd</p>
  </section>
  
  
  
  
  
  
  
    <!--  Main jquery Starts-->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--    Main jquery Ends-->
    
    <!--    Boosstrap js stat-->
    <script src="js/bootstrap.min.js"></script>
    <!--    Bootstarp js Ends--> 
    
    <!--    slick slider js start-->
    <script src="js/slick.js"></script>
    <!--    slick slider js ends-->
    
    <!--    jquery UI starts-->
    <script src="js/jquery-ui.min.js"></script>
    <!--    jquery UI ends-->
    
    <!--    wow js starts-->
    <script src="js/wow.min.js"></script>
    <!--    wow js ends-->
    
  </body>
</html>