<?php $page_heading = "About Us";?>
<?php include 'header.php' ;?>
<img src="images/our_team.png" class="img-responsive" width="100%">

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="latest_deals">
				<h1>About Us</h1>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
			</div>
		</div>
	</div>
</div>
<div class="container">
	<div class="row">
		<div class="col-md-12" style="margin-top: 50px;">
			<div class="col-md-4 no-padding">
				<div class="our_vision">
					<h2>Our Vision</h2>
					<img src="images/vision.jpg" class="img-responsive" width="100%">
				</div>
			</div>
			<div class="col-md-8">
				<div class="vision_test">
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged</p>

					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
					It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged</p>

					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged</p>
				</div>
			</div>
		</div>

		<div class="col-md-12" style="margin-top: 50px;">
			<div class="col-md-8">
				<div class="vision_test">
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged</p>

					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged</p>

					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged</p>
				</div>
			</div>
			<div class="col-md-4 no-padding">
				<div class="our_vision">
					<h2>Our Mission</h2>
					<img src="images/mission.jpg" class="img-responsive" width="100%">
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<div class="our_team">
				<h1>Our Team</h1>
				<p>Our people are our greatest asset and biggest differentiator. They also believe in having a lot of fun along the way.</p>

				<div class="team_mates">
					<div class="col-md-2">
						<img src="images/user-icon.png" class="img-responsive" width="100%">
						<h4>Shahadat Hossain</h4>
						<p>Co-Founder</p>
					</div>
					<div class="col-md-2">
						<img src="images/user-icon.png" class="img-responsive" width="100%">
						<h4>Shahadat Hossain</h4>
						<p>Co-Founder</p>
					</div>
					<div class="col-md-2">
						<img src="images/user-icon.png" class="img-responsive" width="100%">
						<h4>Shahadat Hossain</h4>
						<p>Co-Founder</p>
					</div>
					<div class="col-md-2">
						<img src="images/user-icon.png" class="img-responsive" width="100%">
						<h4>Shahadat Hossain</h4>
						<p>Co-Founder</p>
					</div>
					<div class="col-md-2">
						<img src="images/user-icon.png" class="img-responsive" width="100%">
						<h4>Shahadat Hossain</h4>
						<p>Co-Founder</p>
					</div>
					<div class="col-md-2">
						<img src="images/user-icon.png" class="img-responsive" width="100%">
						<h4>Shahadat Hossain</h4>
						<p>Co-Founder</p>
					</div>

					<div style="clear: both;"></div>
				</div>
			</div>
		</div>
	</div>
</div>


<?php include 'footer.php' ;?>