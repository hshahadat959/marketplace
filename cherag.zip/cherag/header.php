<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?=$page_heading?></title>
    <link rel="icon" href="images/cheraglogo.png" type="image/x-icon">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet"/>
    
    <!--    font-awesome css-->
    <link rel="stylesheet" href="css/font-awesome.min.css"/>
    
    <!--    custom css-->
    <link rel="stylesheet" href="css/style.css"/>
    <link rel="stylesheet" href="css/media.css"/>
    
    <!--    animate css-->
    <link rel="stylesheet" href="css/animate.css"/>
    
    <!--    jquery UI css-->
    <link rel="stylesheet" href="css/jquery-ui.min.css"/>
    <link rel="stylesheet" href="css/jquery-ui.theme.min.css"/>
    
    <!--    slick css-->
    <link rel="stylesheet" href="css/slick.css"/>
    <link rel="stylesheet" href="css/slick-theme.css"/>
    
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  
  <section class="header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <div class="col-md-2 col-sm-3 col-xs-3">
                  <div class="logo">
                      <center><a href="index.php"><img src="images/wt_logo.png"></a></center>
                  </div>
              </div>
              <div class="col-md-10 col-sm-8 col-xs-8 ">
                  <div class="search">
                      <div class="search-criteria"><span>All</span></div>
                      <div class="search_input">
                        <form>
                           <input type="search" placeholder="Wanna Search on Cherag!">
                        </form>
                      </div>
                       
                  </div>
              </div>
            </div>
        </div>
    </div>
  </section>
  <section class="menu">
      <div class="container">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="menu">
                    <nav role="navigation" class="navbar navbar-default mainmenu">
                <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        <!-- Collection of nav links and other content for toggling -->
                        <div id="navbarCollapse" class="collapse navbar-collapse">
                            <ul id="fresponsive" class="nav navbar-nav dropdown">
                                <li class="dropdown"><a data-toggle="dropdown" class="dropdown-toggle">Category<span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="services.php">Services</a></li>
                                        <li><a href="service_details.php">Service Details</a></li>
                                        <li><a href="#">Category 3</a></li>
                                        <li>
                                            <a href="#" data-toggle="dropdown" class="dropdown-toggle">Category with sub category</a>
                                            <ul class="dropdown-menu">
                                                <li><a href="#">Sub Category 1</a></li>
                                                <li><a href="#">Sub Category 2</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#">Category 5</a></li>
                                        <li><a href="#">Category 6</a></li>
                                        <li><a href="#">Category 7</a></li>
                                        <li><a href="#">Category 8</a></li>
                                    </ul>
                                </li>
                                <li><a href="latest_deals.php">Lates Deals</a></li>   
                                <li><a href="promo_code.php">Promo Code</a></li>   
                                <li><a href="#Download">Help</a></li>         
                            </ul>
                            <ul  id="fresponsive" class="nav navbar-nav dropdown navbar-right">
                                <li><a href="upload_service.php">Post Your Add</a></li> 
                                <li><a href="login.php">Log In</a></li> 
                                <li><a href="#Download">Sign Up</a></li>
                                <li><a href="service_provider_profile.php">Profile</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
      </div>
  </section>