 <?php $page_heading = "All Conversations";?>
 <?php include 'header.php' ;?>


<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="location-section">
				<div class="location">
					<h1>Choose Your Location</h1>

					<div class="col-md-6 col-md-offset-3">
						<div class="form-group">
						    <select class="form-control border-select">
						    	<option class="location-name">Ex. Bashundhara R/A</option>
						    </select>
					    </div>
					    <div class="map-marker">
					    	<i class="fa fa-map-marker" aria-hidden="true"></i>
					    </div>
					    <a href="" class="btn btn-default crnt-location-btn">Use your current location</a>

					</div>
					

				</div>
				<div style="clear: both;"></div>
			</div>
		</div>
	</div>
</div>


<style type="text/css">
.border-select {
    background: transparent;
    font-size: 18px;
    height: 50px;
    border: 3px solid #5d5d5d;
    -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0);
}
</style>

 <?php include 'footer.php' ;?>