 <?php $page_heading = "Service Provider Profile";?>
 <?php include 'header.php' ;?>
  <?php include 'service_provider_menu.php' ;?>


<section class="sp_profile">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
					<div class="short_info">
						<label class="switch">
					      <input class="switch-input" type="checkbox" />
					      <span class="switch-label" data-on="Online" data-off="Offline"></span> 
					      <span class="switch-handle"></span> 
					  	</label>
					  	<div class="user-icon">
					  		<img src="images/user-icon.png" class="center">
					  		<h2>Shahadat Hossain</h2>
					  		<p>Professional Website Designer</p>
					  	</div>
					  	<div class="sp_ratting">
					  		<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star"></span>
					  	</div>
					  	<h3 class="contact">CONTACT</h3>
					  	<hr class="hr-3px">

					  	<div class="sp_contact">
					  		<h4><i class="fa fa-map-marker" aria-hidden="true"></i> From : Dhaka</h4>
					  		<h4><i class="fa fa-user" aria-hidden="true"></i> Member Since : 2019</h4>
					  		<h4><i class="fa fa-clock-o" aria-hidden="true"></i> Response Time : 12 mins</h4>
					  	</div>


					</div>
				</div>
				<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
					<div class="service_list">
						<h3>Services</h3>
						<div class=" col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="sp_services">
								<img src="images/service1.png">
								<h4>Packaging Design</h4>
								<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
							</div>
						</div>
						<div class=" col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="sp_services">
								<img src="images/service2.png">
								<h4>Business Cards</h4>
								<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
							</div>
						</div>
						<div class=" col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="sp_services">
								<img src="images/service3.png">
								<h4>Architecture</h4>
								<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
							</div>
						</div>
						<div class=" col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="sp_services">
								<img src="images/service5.png">
								<h4>Album Covers</h4>
								<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
							</div>
						</div>
						<div class=" col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="sp_services">
								<img src="images/service6.png">
								<h4>Stationery</h4>
								<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
							</div>
						</div>
						<div class=" col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="sp_services">
								<img src="images/service4.png">
								<h4>Logo Design</h4>
								<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
							</div>
						</div>
						<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-lg-offset-8 cool-md-offset-8">
							<a href="upload_service.php" class="btn btn-default upload-btn">Upload a service</a>
						</div>
						
					</div>
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h1 class="thm-color" style="margin-bottom: 40px;">About the profile</h1>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
					<div class="sp_describtion thm-color">
						<h3>Description</h3>
						<p>Contrary to popular belief,
							Lorem Ipsum is not simply
							random text. It has roots in
							a piece of cl tin literature
							from 45 BC, making it over
							2000 years old.</p>
						<p>Contrary to popular belief,
							Lorem Ipsum is not simply
							random text. It has roots in
							a piece of cl tin literature
							from 45 BC, making it over
							2000 years old. </p>
						<p>Contrary to popular belief,
							Lorem Ipsum is not simply
							random text. It has roots in
							a piece of cl tin literature
							from 45 BC, making it over
							2000 years old. </p>
						<p>Contrary to popular belief,
							Lorem Ipsum is not simply
							random text. It has roots in
							a piece of cl tin literature
							from 45 BC, making it over
							2000 years old. </p>
						<p>Contrary to popular belief,
							Lorem Ipsum is not simply
							random text. It has roots in
							a piece of cl tin literature
							from 45 BC, making it over
							2000 years old. </p>
						
					</div>
				</div>
				<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
					<h3 class="thm-color" style="margin: 0px;">Reviews</h3>
					<div class="reviews">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
								<img src="images/user-icon.png">
							</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
								<h3 class="sp_name">Riyad Hossein</h3>
								<div class="ratting">
							  		<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star"></span>
							  	</div>
							  	<p class="comment">He is a very good service provider. I prefer him to everyone.</p>
							  	<p class="done_by">Done By <span style="color: #424141;">Shahadat Hossain</span></p>
							</div>
						</div>
						<div style="clear:both"></div>
					</div>
					<div class="reviews">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
								<img src="images/user-icon.png">
							</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
								<h3 class="sp_name">Riyad Hossein</h3>
								<div class="ratting">
							  		<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star"></span>
							  	</div>
							  	<p class="comment">He is a very good service provider. I prefer him to everyone.</p>
							  	<p class="done_by">Done By <span style="color: #424141;">Shahadat Hossain</span></p>
							</div>
						</div>
						<div style="clear:both"></div>
					</div>
					<div class="reviews">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
								<img src="images/user-icon.png">
							</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
								<h3 class="sp_name">Riyad Hossein</h3>
								<div class="ratting">
							  		<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star"></span>
							  	</div>
							  	<p class="comment">He is a very good service provider. I prefer him to everyone.</p>
							  	<p class="done_by">Done By <span style="color: #424141;">Shahadat Hossain</span></p>
							</div>
						</div>
						<div style="clear:both"></div>
					</div>
					<div class="reviews">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
								<img src="images/user-icon.png">
							</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
								<h3 class="sp_name">Riyad Hossein</h3>
								<div class="ratting">
							  		<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star"></span>
							  	</div>
							  	<p class="comment">He is a very good service provider. I prefer him to everyone.</p>
							  	<p class="done_by">Done By <span style="color: #424141;">Shahadat Hossain</span></p>
							</div>
						</div>
						<div style="clear:both"></div>
					</div>
				</div>

				
			</div>
		</div>
	</div>
</section>

<section class="related_works">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h2>Related Works</h2>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service1.png">
						<h4>Packaging Design</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service2.png">
						<h4>Business Cards</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service3.png">
						<h4>Architecture</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service5.png">
						<h4>Album Covers</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service6.png">
						<h4>Stationery</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service4.png">
						<h4>Logo Design</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service6.png">
						<h4>Stationery</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service4.png">
						<h4>Logo Design</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


 <?php include'footer.php' ;?>
