 <?php $page_heading = "Welcome to Cherag";?>
 <?php include 'header.php' ;?>


<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="welcome">
				<h1>Welcome to Shahadat Hossain Let’s post an ad. Choose a option below</h1>
				<div class="col-md-6">
					<div class="sp_type">
						<h3>Sell Something</h3>

						<h4>Sell a service</h4>
						<h4>Property for rent</h4>
					</div>
				</div>
				<div class="col-md-6">
					<div class="sp_type">
						<h3>Looking for something</h3>

						<h4>Buy a service</h4>
						<h4>Buy a property</h4>
					</div>
				</div>
				<div style="clear: both;"></div>
			</div>
		</div>
	</div>
</div>


 <?php include 'footer.php' ;?>