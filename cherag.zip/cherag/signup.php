 <?php $page_heading = "Log in to Cherag";?>
 <?php include 'header.php' ;?>

<div class="container">
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="login">
				<img src="images/cheraglogo.png" class="center">
				<h3>Continue with</h3>
				<div class="social-buttons center">
                  <center>
                  		<a href="#" class="btn btn-fb "><i class="fa fa-facebook"></i> Facebook</a>
                  		<a href="#" class="btn btn-tw"><i class="fa fa-google"></i> Google</a>
                  </center>
               </div>
				<h3>-----Or-----</h3>
				<h3>Signup with email address</h3>
				<form action="">
				  <div class="form-group col-lg-4 col-md-4 col-lg-offset-4 col-md-offset-4">
				    <input type="text" class="form-control" id="signup-name" placeholder="Enter you Name">
				  </div>
				  <div class="form-group col-lg-4 col-md-4 col-lg-offset-4 col-md-offset-4">
				    <input type="email" class="form-control" id="email" placeholder="Enter email">
				  </div>
				  <div class="form-group col-lg-4 col-md-4 col-lg-offset-4 col-md-offset-4">
				    <select class="form-control border-select">
				    	<option>Select account type</option>
				    	<option>Normal User</option>
				    	<option>Service Provider</option>
				    	<option>Affiliator</option>
				    </select>
				  </div>
				  <div class="form-group col-lg-4 col-md-4 col-lg-offset-4 col-md-offset-4">
				    <select class="form-control border-select">
				    	<option>Select your location</option>
				    	<option>Bashundhara</option>
				    	<option>Mirpur</option>
				    	<option>Dhanmondi</option>
				    </select>
				  </div>
				  <div class="form-group col-lg-4 col-md-4 col-lg-offset-4 col-md-offset-4">
				    <input type="password" class="form-control" id="password" placeholder="Enter password">
				  </div>
				  <div class="form-group col-lg-4 col-md-4 col-lg-offset-4 col-md-offset-4">
				    <input type="password" class="form-control" id="password" placeholder="Confirm password">
				  </div>
				  <div class="col-lg-4 col-md-4 col-lg-offset-4 col-md-offset-4">
				  	<button type="submit" class="btn btn-default login-btn">Login</button>
				  	<span style="color: #6c6c6e;">Already have in <a href="" style="color: #403f3f; font-size: 15px;">Cherag</a>? <a href="login.php" style="color: #403f3f; text-decoration: underline;">Log In</a>  now!</span>
				  </div>
				</form>
				<div style="clear: both;"></div>
			</div>
		</div>
	</div>	
</div>

<style type="text/css">
.border-select {
    background: transparent;
    font-size: 18px;
    height: 49px;
    border: 3px solid #5d5d5d;
    -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0);
}

input[type=text]:-moz-placeholder {
	color: #5d5d5d;
	font-size: 18px;
}
input[type=text]::-webkit-input-placeholder {
	color: #5d5d5d;
	font-size: 18px;
}
input[type=email]:-moz-placeholder {
	color: #5d5d5d;
	font-size: 18px;
}
input[type=email]::-webkit-input-placeholder {
	color: #5d5d5d;
	font-size: 18px;
}
input[type=password]:-moz-placeholder {
	color: #5d5d5d;
	font-size: 18px;
}
input[type=password]::-webkit-input-placeholder {
	color: #5d5d5d;
	font-size: 18px;
}
</style>
 <?php include 'footer.php' ;?>


