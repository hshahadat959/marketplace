 <?php $page_heading = "Upload a service";?>
 <?php include 'header.php';?>
 <?php include 'service_provider_menu.php' ;?>

 <div class="container">
 	<div class="row">
 		<div class="col-lg-12 col-md-12">
 			<div class="promo_code">

 				<form action="">
        		  
				  	<div class="form-group">
					 	<h2 class="promo_code_head sansserif" style="text-align: center;">Enter Your Email Address and <br/> Get 10% Discount</h2>
				    </div>

					  
					<div class="form-group">
	        		  <center>	<input type="text" class="form-control promo_code_email" name="" placeholder="hasib.ascend@gmail.com"></center>
					</div>

					<div class="" style="text-align: center;">
						<div class="form-group">
							<button type="button" class="btn btn-default send_promo_code">Send Promo Code</button>
							
						</div>
					</div>

					<div class="form-group">
					 	<h2 style="text-align: center;" class="promo_code_details sansserif">Use the promo code at the purchase that will be sent to <br/> your email address to avail the discount</h2>
				    </div>
				
				</form>
				
 			</div>
 		</div>
 	</div>
 </div>


<?php include 'footer.php' ;?>
<style type="text/css">
	/* promo code */
.promo_code{
   background: #ebebeb;
}
h2.promo_code_head{
    text-align: center;
    font-size: 20px;
    background: #ebebeb;
    padding: 10px 0px;
    color: #585555;
    font-size: 30px;
    text-align: center;
    padding-top: 125px;
}
input.promo_code_email{
    text-align: center;
    font-size: 20px;
    background: #ebebeb;
    padding: 10px 0px;
    border-width:3px;
    border-color: #696565;
    width: 35%;
    padding-top: 30px;
    padding-bottom: 25px;
    border-radius: 12px;
}
button.send_promo_code{
    text-align: center;
    font-size: 15px;
    background: #635c5c;
    padding: 10px 10px;
    color: white;
    font-style: oblique;
    border-radius: 12px;
    padding-top: 15px;
    margin-top: 40px;
}
h2.promo_code_details{
    text-align: center;
    font-size: 20px;
    background: #ebebeb;
    padding: 10px 0px;
    color: #71716d;
    text-align: center;
    padding-top: 80px;
    padding-bottom: 50px;
}
</style>