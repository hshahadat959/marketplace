 <?php $page_heading = "All Conversations";?>
 <?php include 'header.php' ;?>


<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="welcome">
				<div class="sell_item">
					<h2>Sell an item or service</h2>
					<div class="col-md-6">
						<h3>Select a category</h3>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
					</div>
					<div class="col-md-6">
						<h3>Select a Sub Category</h3>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
						<p>Name Here</p>
					</div>
					<div style="clear: both;"></div>
				</div>
				
			</div>
		</div>
	</div>
</div>


 <?php include 'footer.php' ;?>