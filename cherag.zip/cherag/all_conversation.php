 <?php $page_heading = "All Conversations";?>
 <?php include 'header.php' ;?>
 <?php include 'service_provider_menu.php' ;?>
<section class="all_conversation">
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<div class="all_persons">
					<h5>All Conversations</h5>
					<div class="all_conv">
						<div class="conversations">
							<table class="col-sm-12 col-xs-12">
       
						        <tbody class="table table-border">  
						            <tr>
						                <td class="" style=" padding: 0px 10px;"><img style="border-radius: 50%;width: 65px; height: 65px;border: 2px solid #5d5d5d;" src="images/user-icon.png" class="img-responsive">
						                    <span class="chat_name">Riyad Hossain</span>
						                    <span class="short_chat">Me: Let me know about....</span>
						                </td>
						            </tr>
						        </tbody>
						    </table>
						    <div style="clear: both;"></div>
						</div>
						<div class="conversations">
							<table class="col-sm-12 col-xs-12">
       
						        <tbody class="table table-border">  
						            <tr>
						                <td class="" style=" padding: 0px 10px;"><img style="border-radius: 50%;width: 65px; height: 65px;border: 2px solid #5d5d5d;" src="images/user-icon.png" class="img-responsive">
						                    <span class="chat_name">Riyad Hossain</span>
						                    <span class="short_chat">Me: Let me know about....</span>
						                </td>
						            </tr>
						        </tbody>
						    </table>
						    <div style="clear: both;"></div>
						</div>
						<div class="conversations">
							<table class="col-sm-12 col-xs-12">
       
						        <tbody class="table table-border">  
						            <tr>
						                <td class="" style=" padding: 0px 10px;"><img style="border-radius: 50%;width: 65px; height: 65px;border: 2px solid #5d5d5d;" src="images/user-icon.png" class="img-responsive">
						                    <span class="chat_name">Riyad Hossain</span>
						                    <span class="short_chat">Me: Let me know about....</span>
						                </td>
						            </tr>
						        </tbody>
						    </table>
						    <div style="clear: both;"></div>
						</div>

						<div class="conversations">
							<table class="col-sm-12 col-xs-12">
       
						        <tbody class="table table-border">  
						            <tr>
						                <td class="" style=" padding: 0px 10px;"><img style="border-radius: 50%;width: 65px; height: 65px;border: 2px solid #5d5d5d;" src="images/user-icon.png" class="img-responsive">
						                    <span class="chat_name">Riyad Hossain</span>
						                    <span class="short_chat">Me: Let me know about....</span>
						                </td>
						            </tr>
						        </tbody>
						    </table>
						    <div style="clear: both;"></div>
						</div>
						<div class="conversations">
							<table class="col-sm-12 col-xs-12">
       
						        <tbody class="table table-border">  
						            <tr>
						                <td class="" style=" padding: 0px 10px;"><img style="border-radius: 50%;width: 65px; height: 65px;border: 2px solid #5d5d5d;" src="images/user-icon.png" class="img-responsive">
						                    <span class="chat_name">Riyad Hossain</span>
						                    <span class="short_chat">Me: Let me know about....</span>
						                </td>
						            </tr>
						        </tbody>
						    </table>
						    <div style="clear: both;"></div>
						</div>
						<div class="conversations">
							<table class="col-sm-12 col-xs-12">
       
						        <tbody class="table table-border">  
						            <tr>
						                <td class="" style=" padding: 0px 10px;"><img style="border-radius: 50%;width: 65px; height: 65px;border: 2px solid #5d5d5d;" src="images/user-icon.png" class="img-responsive">
						                    <span class="chat_name">Riyad Hossain</span>
						                    <span class="short_chat">Me: Let me know about....</span>
						                </td>
						            </tr>
						        </tbody>
						    </table>
						    <div style="clear: both;"></div>
						</div>
						<div class="conversations">
							<table class="col-sm-12 col-xs-12">
       
						        <tbody class="table table-border">  
						            <tr>
						                <td class="" style=" padding: 0px 10px;"><img style="border-radius: 50%;width: 65px; height: 65px;border: 2px solid #5d5d5d;" src="images/user-icon.png" class="img-responsive">
						                    <span class="chat_name">Riyad Hossain</span>
						                    <span class="short_chat">Me: Let me know about....</span>
						                </td>
						            </tr>
						        </tbody>
						    </table>
						    <div style="clear: both;"></div>
						</div>
					</div>
					<div style="clear: both;"></div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="main_chat_middle">
					<h4><i class="fa fa-circle" aria-hidden="true" style="color: #5CA53A"></i> Shahadat Hossain</h4>
					<span class="last_seen">Last Seen 2 hrs ago | Local Time Dec 20, 7:00 pm</span>
					<div class="main_chat">
					<div class="main_chat_scroll">
						<div class="chat-party-one">
							<h5><i class="fa fa-user-circle"></i> Shahadat Hossain</h5>
							<div class="chat-party-one_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div class="chat-party-two">
							<h5> Riyad Hossain <i class="fa fa-user-circle"></i></h5>
							<div class="chat-party-two_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div style="clear: both;"></div>
						<div class="chat-party-one">
							<h5><i class="fa fa-user-circle"></i> Shahadat Hossain</h5>
							<div class="chat-party-one_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div class="chat-party-two">
							<h5> Riyad Hossain <i class="fa fa-user-circle"></i></h5>
							<div class="chat-party-two_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div style="clear: both"></div>
						<div class="chat-party-one">
							<h5><i class="fa fa-user-circle"></i> Shahadat Hossain</h5>
							<div class="chat-party-one_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div class="chat-party-two">
							<h5> Riyad Hossain <i class="fa fa-user-circle"></i></h5>
							<div class="chat-party-two_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div style="clear: both;"></div>
						<div class="chat-party-one">
							<h5><i class="fa fa-user-circle"></i> Shahadat Hossain</h5>
							<div class="chat-party-one_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div class="chat-party-two">
							<h5> Riyad Hossain <i class="fa fa-user-circle"></i></h5>
							<div class="chat-party-two_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div style="clear: both"></div>
						<div class="chat-party-one">
							<h5><i class="fa fa-user-circle"></i> Shahadat Hossain</h5>
							<div class="chat-party-one_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div class="chat-party-two">
							<h5> Riyad Hossain <i class="fa fa-user-circle"></i></h5>
							<div class="chat-party-two_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div style="clear: both;"></div>
						<div class="chat-party-one">
							<h5><i class="fa fa-user-circle"></i> Shahadat Hossain</h5>
							<div class="chat-party-one_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div class="chat-party-two">
							<h5> Riyad Hossain <i class="fa fa-user-circle"></i></h5>
							<div class="chat-party-two_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div style="clear: both"></div>
						</div>

					<div class="chat_input">
						<form class="example" action="">
						  <input type="text" placeholder="Write message here..." name="send">
						  <button type="submit">Send</button>
						</form>


					</div>
					<p class="emoticon"><i class="fa fa-smile-o"></i> &nbsp; <i class="fa fa-upload"></i></p>
					<div style="clear: both"></div>
				</div>

				
			</div>
		</div>
		<div class="col-md-3">
			<div class="about_person">
				<h2></h2>
				<center><img style="border-radius: 50%;width: 65px; height: 65px;border: 2px solid #5d5d5d;" src="images/user-icon.png" class="img-responsive"></center>
				<h3>Shahadat Hossain</h3>
				<p>Buyer</p>
				<div class="sp_ratting">
			  		<span class="fa fa-star checked"></span>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star"></span>
			  	</div>
			</div>
		</div>
	</div>
			
		</div>
	</div>
</section>
<style type="text/css">


form.example input[type=text] {
    padding: 10px;
    font-size: 17px;
    float: left;
    width: 80%;
    background: #fff;
    border: none;
    border-radius: 5px 0px 0px 5px;
}

form.example button {
  float: left;
  width: 20%;
  padding: 10px;
  color: #5d5d5d;
  font-size: 17px;
  cursor: pointer;
  background: #fff;
  border: none;
  border-radius: 0px 5px 5px 0px;
  font-family: arboria-bold;
}
.main_chat {
    padding: 0px 10px 10px 10px;
    border-top: 2px solid #c6c6c6;
}
</style>
 <?php include 'footer.php' ;?> 