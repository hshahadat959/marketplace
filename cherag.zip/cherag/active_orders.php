 <?php $page_heading = "Service Provider Profile";?>
 <?php include 'header.php' ;?>
<?php include 'service_provider_menu.php' ;?>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="earnings">
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
					<div class="short_info">
						<label class="switch">
					      <input class="switch-input" type="checkbox" />
					      <span class="switch-label" data-on="Online" data-off="Offline"></span> 
					      <span class="switch-handle"></span> 
					  	</label>
					  	<div class="user-icon">
					  		<img src="images/user-icon.png" class="center">
					  		<h2>Shahadat Hossain</h2>
					  		<p>Professional Website Designer</p>
					  	</div>
					  	<div class="sp_ratting">
					  		<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star"></span>
					  	</div>
					  	<h3 class="contact">CONTACT</h3>
					  	<hr class="hr-3px">

					  	<div class="sp_contact">
					  		<h4><i class="fa fa-map-marker" aria-hidden="true"></i> From : Dhaka</h4>
					  		<h4><i class="fa fa-user" aria-hidden="true"></i> Member Since : 2019</h4>
					  		<h4><i class="fa fa-clock-o" aria-hidden="true"></i> Response Time : 12 mins</h4>
					  	</div>


					</div>
				</div>
				<div class="col-md-8">
					<div class="active_orders">
						<h4>Active Orders <i class="fa fa-circle" aria-hidden="true" style="color: #5CA53A"></i></h4>

						<div class="active_orders_list">
							<div class="col-md-12">
								<div class="col-md-3 src-icon">
									<img src="images/service3.png" class="img-responsive" >
								</div>
								<div class="col-md-6 srvc-name-dtls">
									<h4>About the Service</h4>
									<p>Buyer Name: hjgh</p>
								</div>
								<div class="col-md-3 time-remaining">
									<p>2000 bdt</p>
									<p>7 hrs remaining</p>
								</div>
							</div>
							<div style="clear: both;"></div>
						</div>

						<div class="active_orders_list">
							<div class="col-md-12">
								<div class="col-md-3 src-icon">
									<img src="images/service3.png" class="img-responsive" >
								</div>
								<div class="col-md-6 srvc-name-dtls">
									<h4>About the Service</h4>
									<p>Buyer Name: hjgh</p>
								</div>
								<div class="col-md-3 time-remaining">
									<p>2000 bdt</p>
									<p>7 hrs remaining</p>
								</div>
							</div>
							<div style="clear: both;"></div>
						</div>

						<div class="active_orders_list">
							<div class="col-md-12">
								<div class="col-md-3 src-icon">
									<img src="images/service3.png" class="img-responsive" >
								</div>
								<div class="col-md-6 srvc-name-dtls">
									<h4>About the Service</h4>
									<p>Buyer Name: hjgh</p>
								</div>
								<div class="col-md-3 time-remaining">
									<p>2000 bdt</p>
									<p>7 hrs remaining</p>
								</div>
							</div>
							<div style="clear: both;"></div>
						</div>

						<div class="active_orders_list">
							<div class="col-md-12">
								<div class="col-md-3 src-icon">
									<img src="images/service3.png" class="img-responsive" >
								</div>
								<div class="col-md-6 srvc-name-dtls">
									<h4>About the Service</h4>
									<p>Buyer Name: hjgh</p>
								</div>
								<div class="col-md-3 time-remaining">
									<p>2000 bdt</p>
									<p>7 hrs remaining</p>
								</div>
							</div>
							<div style="clear: both;"></div>
						</div>

						<div class="active_orders_list">
							<div class="col-md-12">
								<div class="col-md-3 src-icon">
									<img src="images/service3.png" class="img-responsive" >
								</div>
								<div class="col-md-6 srvc-name-dtls">
									<h4>About the Service</h4>
									<p>Buyer Name: hjgh</p>
								</div>
								<div class="col-md-3 time-remaining">
									<p>2000 bdt</p>
									<p>7 hrs remaining</p>
								</div>
							</div>
							<div style="clear: both;"></div>
						</div>
					</div>
				</div>
				<div style="clear: both;"></div>
			</div>
		</div>
	</div>
</div>

<?php include 'footer.php' ;?>