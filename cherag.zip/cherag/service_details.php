 <?php $page_heading = "Service Details";?>
 <?php include 'header.php' ;?>
 <?php include 'service_provider_menu.php' ;?>
<style>
		/* CSS used here will be applied after bootstrap.css */
		.carousel {
			margin-top: 20px;
		}
		.item .thumb {
			width: 25%;
			cursor: pointer;
			float: left;
		}
		.item .thumb img {
			width: 100%;
			margin: 2px;
		}
		.item img {
			width: 100%;	
		}
		.carousel-inner>.item>a>img, .carousel-inner>.item>img {
		    height: 400px;
		}

	</style>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="service_detail">
				<h3 class="ssp">Seller Service Portfolio</h3>
				<h2 class="stgh">Service Title Goes Here</h2>
				<hr class="service_detail_hr">
				<p style="text-align: center; margin: 0px;">Category/Subcategory</p>
			</div>
		</div>

		    <div class="col-md-8 col-md-offset-2">
		        <div id="carousel" class="carousel slide" data-ride="carousel">
		            <div class="carousel-inner">
		                <div class="item active">
		                    <img src="images/service1.png" height="400px">
		                </div>
		                <div class="item">
		                    <img src="images/service2.png" height="400px">
		                </div>
		                <div class="item">
		                    <img src="images/service3.png" height="400px">
		                </div>
		                <div class="item">
		                    <img src="images/service4.png" height="400px">
		                </div>
		                <div class="item">
		                    <img src="images/service5.png" height="400px">
		                </div>
		                <div class="item">
		                    <img src="images/service6.png" height="400px">
		                </div>
		                <div class="item">
		                    <img src="images/service1.png" height="400px">
		                </div>
		                <div class="item">
		                    <img src="images/service2.png" height="400px">
		                </div>
		            </div>
		        </div> 
		    <div class="clearfix">
		        <div id="thumbcarousel" class="carousel slide" data-interval="false">
		            <div class="carousel-inner">
		                <div class="item active">
		                    <div data-target="#carousel" data-slide-to="0" class="thumb"><img src="images/service1.png" height="150px"></div>
		                    <div data-target="#carousel" data-slide-to="1" class="thumb"><img src="images/service2.png" height="150px"></div>
		                    <div data-target="#carousel" data-slide-to="2" class="thumb"><img src="images/service3.png" height="150px"></div>
		                    <div data-target="#carousel" data-slide-to="3" class="thumb"><img src="images/service4.png" height="150px"></div>
		                </div><!-- /item -->
		                <div class="item">
		                    <div data-target="#carousel" data-slide-to="4" class="thumb"><img src="images/service5.png" height="150px"></div>
		                    <div data-target="#carousel" data-slide-to="5" class="thumb"><img src="images/service6.png" height="150px"></div>
		                    <div data-target="#carousel" data-slide-to="6" class="thumb"><img src="images/service1.png" height="150px"></div>
		                    <div data-target="#carousel" data-slide-to="7" class="thumb"><img src="images/service2.png" height="150px"></div>
		                </div><!-- /item -->
		            </div><!-- /carousel-inner -->
		            <a class="left carousel-control" href="#thumbcarousel" role="button" data-slide="prev">
		                <span class="glyphicon glyphicon-chevron-left"></span>
		            </a>
		            <a class="right carousel-control" href="#thumbcarousel" role="button" data-slide="next">
		                <span class="glyphicon glyphicon-chevron-right"></span>
		            </a>
		        </div> <!-- /thumbcarousel -->
		    </div><!-- /clearfix -->
		    </div>



		    <div class="col-md-12">
		    	<div class="package_details">
			    	<div class="col-md-8">
			    		<h3>Packagess</h3>
			    		<table width="100%" class="table">
			    			<thead>
			    				<tr>
				    				<th></th>
				    				<th><span class="pack1">1000 BDT</span></th>
				    				<th><span class="pack2">2000 BDT</span></td>
				    				<th><span class="pack3">3000 BDT</span></th>
				    			</tr>
			    			</thead>

			    			<tr>
			    				<td>Description</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    			</tr>
			    			<tr>
			    				<td>Service Name</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    			</tr>
			    			<tr>
			    				<td>Service Name</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    			</tr>
			    			<tr>
			    				<td>Service Name</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    			</tr>
			    			<tr>
			    				<td>Service Name</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    			</tr>
			    			<tr>
			    				<td>Service Name</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    			</tr>
			    			<tr>
			    				<td>Service Name</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    			</tr>
			    			<tr>
			    				<td>Service Name</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    			</tr>
			    			<tr>
			    				<td>Service Name</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    			</tr>
			    			<tr>
			    				<td>Service Name</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    				<td>Text</td>
			    			</tr>
			    			<tr style="border-bottom: 1px solid #ddd;">
			    				<td>Time</td>
			    				<td>2 Days</td>
			    				<td>3 Days</td>
			    				<td>4 Days</td>
			    			</tr>
			    			<tr>
			    				<td colspan="3"></td> 
			    				<td><a href="" class="btn btn-default pack-edt-btn">Edit</a></td>
			    			</tr>
			    		</table>
			    	</div>

			    	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
						<div class="short_info">
							<label class="switch">
						      <input class="switch-input" type="checkbox" />
						      <span class="switch-label" data-on="Online" data-off="Offline"></span> 
						      <span class="switch-handle"></span> 
						  	</label>
						  	<div class="user-icon">
						  		<img src="images/user-icon.png" class="center">
						  		<h2>Shahadat Hossain</h2>
						  		<p>Professional Website Designer</p>
						  	</div>
						  	<div class="sp_ratting">
						  		<span class="fa fa-star checked"></span>
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star"></span>
						  	</div>
						  	<h3 class="contact">CONTACT</h3>
						  	<hr class="hr-3px">

						  	<div class="sp_contact">
						  		<h4><i class="fa fa-map-marker" aria-hidden="true"></i> From : Dhaka</h4>
						  		<h4><i class="fa fa-user" aria-hidden="true"></i> Member Since : 2019</h4>
						  		<h4><i class="fa fa-clock-o" aria-hidden="true"></i> Response Time : 12 mins</h4>
						  	</div>


						</div>
					</div>
					<div style="clear: both;"></div>
		    	</div>
		    </div>
		</div>
</div>

<div class="container">
	<div class="row">
		<div class="col-md-7">
			<h2 style="color: #5d5d5d;">About the Service</h2>
			<div class="about_service">
				<div class="col-md-9" style="border-right: 2px solid #5d5d5d;">
					<p>Contrary to popular belief, Lorem Ipsum is not simply
					random text. It has roots in a piece of cl tin literature
					from 45 BC, making it over Contrary to popular belief,
					Lorem Ipsum is not simply random text.</p>
					<p>	Contrary to popular belief, Lorem Ipsum is not simply
						random text. It has roots in a piece of cl tin literature
						from 45 BC, making it over Contrary to popular belief,
						Lorem Ipsum is not simply random text.</p>
					<p>	Contrary to popular belief, Lorem Ipsum is not simply
						random text. It has roots in a piece of cl tin literature
						from 45 BC, making it over Contrary to popular belief,
						Lorem Ipsum is not simply random text.</p>
					<p>	Contrary to popular belief, Lorem Ipsum is not simply
						random text. It has roots in a piece of cl tin literature
						from 45 BC, making it over Contrary to popular belief,
						Lorem Ipsum is not simply random text.</p>
					<p>	Contrary to popular belief, Lorem Ipsum is not simply
						random text. It has roots in a piece of cl tin literature
						from 45 BC, making it over Contrary to popular belief,
						Lorem Ipsum is not simply random text.</p>
					<p>	Contrary to popular belief, Lorem Ipsum is not simply
						random text. It has roots in a piece of cl tin literature
						from 45 BC, making it over Contrary to pop</p>
				</div>
				<div class="col-md-3">
					<div class="aboutsrc">
						<h3>Text Here</h3>
						<p>Text Here</p>
						<hr style="border: 1px solid #5d5d5d; margin: 5pxp 0px;">
						<h3 style="margin-top: 5px;">Text Here</h3>
						<p>Text Here</p>

						<p style="margin-top: 20px">Text Here</p>
						<p>Text Here</p>
						<p>Text Here</p>
						<p>Text Here</p>
						<p>Text Here</p>
						<p>Text Here</p>
						<p>Text Here</p>
						<p>Text Here</p>
					</div>
				</div>
				<div style="clear: both;"></div>
			</div>
		</div>
		<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
			<h3 class="thm-color" style="margin: 0px;">Reviews</h3>
			<div class="reviews">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="col-lg-4 col-md-4 col-sm-2 col-xs-2">
						<img src="images/user-icon.png">
					</div>
					<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
						<h3 class="sp_name">Riyad Hossein</h3>
						<div class="ratting">
					  		<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star"></span>
					  	</div>
					  	<p class="comment">He is a very good service provider. I prefer him to everyone.</p>
					  	<p class="done_by">Done By <span style="color: #424141;">Shahadat Hossain</span></p>
					</div>
				</div>
				<div style="clear:both"></div>
			</div>
			<div class="reviews">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="col-lg-4 col-md-4 col-sm-2 col-xs-2">
						<img src="images/user-icon.png">
					</div>
					<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
						<h3 class="sp_name">Riyad Hossein</h3>
						<div class="ratting">
					  		<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star "></span>
							<span class="fa fa-star"></span>
					  	</div>
					  	<p class="comment">He is a very good service provider. I prefer him to everyone.</p>
					  	<p class="done_by">Done By <span style="color: #424141;">Shahadat Hossain</span></p>
					</div>
				</div>
				<div style="clear:both"></div>
			</div>
			<div class="reviews">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="col-lg-4 col-md-4 col-sm-2 col-xs-2">
						<img src="images/user-icon.png">
					</div>
					<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
						<h3 class="sp_name">Riyad Hossein</h3>
						<div class="ratting">
					  		<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star "></span>
							<span class="fa fa-star"></span>
					  	</div>
					  	<p class="comment">He is a very good service provider. I prefer him to everyone.</p>
					  	<p class="done_by">Done By <span style="color: #424141;">Shahadat Hossain</span></p>
					</div>
				</div>
				<div style="clear:both"></div>
			</div>
			<div class="reviews">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="col-lg-4 col-md-4 col-sm-2 col-xs-2">
						<img src="images/user-icon.png">
					</div>
					<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
						<h3 class="sp_name">Riyad Hossein</h3>
						<div class="ratting">
					  		<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star"></span>
					  	</div>
					  	<p class="comment">He is a very good service provider. I prefer him to everyone.</p>
					  	<p class="done_by">Done By <span style="color: #424141;">Shahadat Hossain</span></p>
					</div>
				</div>
				<div style="clear:both"></div>
			</div>
		</div>
	</div>
</div>

<section class="related_works">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h2>Related Works</h2>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service1.png">
						<h4>Packaging Design</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service2.png">
						<h4>Business Cards</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service3.png">
						<h4>Architecture</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service5.png">
						<h4>Album Covers</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service6.png">
						<h4>Stationery</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service4.png">
						<h4>Logo Design</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service6.png">
						<h4>Stationery</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
				<div class=" col-lg-3 col-md-3 col-sm-6 col-xs-6">
					<div class="sp_services">
						<img src="images/service4.png">
						<h4>Logo Design</h4>
						<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


 <?php include 'footer.php' ;?> 
