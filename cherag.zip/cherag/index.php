<?php $page_heading = "cherag.com.bd";?>
 <?php include 'header.php' ;?>

  <section class="main-slider">
             <div class="container-fluid slider">
          <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
              <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
              <li data-target="#myCarousel" data-slide-to="1"></li>
              <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner">
              <div class="item active">
                <img src="images/baner.png" alt="Los Angeles" style="width:100%;">
              </div>

              <div class="item">
                <img src="images/baner1.png" alt="Chicago" style="width:100% ;">
              </div>
            
              <div class="item">
                <img src="images/baner2.png" alt="New york" style="width:100%;">
              </div>
            </div>

            <!-- Left and right controls -->
            <a class="left carousel-control" href="#myCarousel" data-slide="prev">
              <span class="glyphicon glyphicon-chevron-left"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next">
              <span class="glyphicon glyphicon-chevron-right"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
        </div>
  </section>
  <section class="add-post">
      <div class="container">
          <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <div class="post-add">
                      <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5 col-lg-offset-1 col-md-offset-1 col-sm-offset-1 col-xs-offset-1 ">
                          <a href="post-add.php" class="btn btn-primary post-add-btn">Post Your Add!</a>
                      </div>
                      <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5 ">
                          <a href="post-add.php" class="btn btn-primary post-add-btn">Become an Affiliate</a>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </section>
    <section class="service">
        <div class="container">
            <div class='row'>
              <div class='col-md-12'>
                <div class="carousel slide media-carousel " id="service-logo"service>
                  <div class="carousel-inner ">
                    <div class="item  active">
                      <div class="row">
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 poster">
                          <center><a class="" href="#">
                            <div class="service-image">
                              <img alt="" src="images/services1.png" class="service-img">
                              <h5 class="cat-name">Catagory Name</h5>
                              <div class="overlay">
                                  <div class="text">Service Description</div>
                              </div>
                            </div>
                          </a></center>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 poster">
                          <center><a class="" href="#">
                            <div class="service-image">
                              <img alt="" src="images/services1.png" class="service-img">
                              <h5 class="cat-name">Catagory Name</h5>
                              <div class="overlay">
                                  <div class="text">Service Description</div>
                              </div>
                            </div>
                          </a></center>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 poster">
                          <center><a class="" href="#">
                            <div class="service-image">
                              <img alt="" src="images/services1.png" class="service-img">
                              <h5 class="cat-name">Catagory Name</h5>
                              <div class="overlay">
                                  <div class="text">Service Description</div>
                              </div>
                            </div>
                          </a></center>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 poster">
                          <center><a class="" href="#">
                            <div class="service-image">
                              <img alt="" src="images/services1.png" class="service-img">
                              <h5 class="cat-name">Catagory Name</h5>
                              <div class="overlay">
                                  <div class="text">Service Description</div>
                              </div>
                            </div>
                          </a></center>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 poster">
                          <center><a class="" href="#">
                            <div class="service-image">
                              <img alt="" src="images/services1.png" class="service-img">
                              <h5 class="cat-name">Catagory Name</h5>
                              <div class="overlay">
                                  <div class="text">Service Description</div>
                              </div>
                            </div>
                          </a></center>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 poster">
                          <center><a class="" href="#">
                            <div class="service-image">
                              <img alt="" src="images/services1.png" class="service-img">
                              <h5 class="cat-name">Catagory Name</h5>
                              <div class="overlay">
                                  <div class="text">Service Description</div>
                              </div>
                            </div>
                          </a></center>
                        </div>

                             
                        
                  
                      </div>
                    </div>
                    <div class="item">
                      <div class="row">
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 poster">
                          <center><a class="" href="#">
                            <div class="service-image">
                              <img alt="" src="images/services1.png" class="service-img">
                              <h5 class="cat-name">Catagory Name</h5>
                              <div class="overlay">
                                  <div class="text">Service Description</div>
                              </div>
                            </div>
                          </a></center>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 poster">
                          <center><a class="" href="#">
                            <div class="service-image">
                              <img alt="" src="images/services1.png" class="service-img">
                              <h5 class="cat-name">Catagory Name</h5>
                              <div class="overlay">
                                  <div class="text">Service Description</div>
                              </div>
                            </div>
                          </a></center>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 poster">
                          <center><a class="" href="#">
                            <div class="service-image">
                              <img alt="" src="images/services1.png" class="service-img">
                              <h5 class="cat-name">Catagory Name</h5>
                              <div class="overlay">
                                  <div class="text">Service Description</div>
                              </div>
                            </div>
                          </a></center>
                        </div> 
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 poster">
                          <center><a class="" href="#">
                            <div class="service-image">
                              <img alt="" src="images/services1.png" class="service-img">
                              <h5 class="cat-name">Catagory Name</h5>
                              <div class="overlay">
                                  <div class="text">Service Description</div>
                              </div>
                            </div>
                          </a></center>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 poster">
                          <center><a class="" href="#">
                            <div class="service-image">
                              <img alt="" src="images/services1.png" class="service-img">
                              <h5 class="cat-name">Catagory Name</h5>
                              <div class="overlay">
                                  <div class="text">Service Description</div>
                              </div>
                            </div>
                          </a></center>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 poster">
                          <center><a class="" href="#">
                            <div class="service-image">
                              <img alt="" src="images/services1.png" class="service-img">
                              <h5 class="cat-name">Catagory Name</h5>
                              <div class="overlay">
                                  <div class="text">Service Description</div>
                              </div>
                            </div>
                          </a></center>
                        </div>   
                      </div>
                    </div>
                  </div>
                  <a data-slide="prev" href="#service-logo" class="left sl carousel-control">‹</a>
                  <a data-slide="next" href="#service-logo" class="right sl carousel-control">›</a>
                </div>                          
              </div>
            </div>
          </div>
                  
  </section>

  <h1 class="service-slide-title">Services & Slideshows Here</h1>
  
  <section class="service-slide">
    <div class="container">
      <div class='row'>
        <div class='col-md-12'>
          <div class="carousel slide media-carousel " id="action">
            <div class="carousel-inner ">
              <div class="item  active">
                <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service1.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service2.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service3.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                       
                  
            
                </div>
              </div>
              <div class="item">
                <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service4.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service5.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service6.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>   
                </div>
              </div>
            </div>
            <a data-slide="prev" href="#action" class="left carousel-control">‹</a>
            <a data-slide="next" href="#action" class="right carousel-control">›</a>
          </div>                          
        </div>


        <div class='col-md-12'>
          <div class="carousel slide media-carousel " id="action1">
            <div class="carousel-inner ">
              <div class="item  active">
                <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service1.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service2.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service3.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                       
                  
            
                </div>
              </div>
              <div class="item">
                <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service4.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service5.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service6.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>   
                </div>
              </div>
            </div>
            <a data-slide="prev" href="#action1" class="left carousel-control">‹</a>
            <a data-slide="next" href="#action1" class="right carousel-control">›</a>
          </div>                          
        </div>


        <div class='col-md-12'>
          <div class="carousel slide media-carousel " id="action2">
            <div class="carousel-inner ">
              <div class="item  active">
                <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service1.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service2.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service3.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                       
                  
            
                </div>
              </div>
              <div class="item">
                <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service4.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service5.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
                    <center><a class="" href="#">
                      <div class="service-logo">
                        <img alt="" src="images/service6.png" class="service-img">
                        <div class="overlay">
                            <div class="text">Service Description</div>
                        </div>
                      </div>
                    </a></center>
                  </div>   
                </div>
              </div>
            </div>
            <a data-slide="prev" href="#action2" class="left carousel-control">‹</a>
            <a data-slide="next" href="#action2" class="right carousel-control">›</a>
          </div>                          
        </div>
      </div>
    </div>
      
    
  </section>
  <section class="partners">
    <h1>Our Partners</h1>

    <div class="container">
        <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                <img src="images/logo.png"> 
            </div>
            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                <img src="images/bdsoftlogo.png"> 
            </div>
            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                <img src="images/google.jpg"> 
            </div>
            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                <img src="images/youtube.png"> 
            </div>
            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                <img src="images/fb.png"> 
            </div>
            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                <img src="images/logo.png"> 
            </div>
            
        </div>
    </div>
  </section>
    <section class="members">
    <h1>Our Valued Members</h1>

    <div class="container">
        <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                <img src="images/logo.png" class="img-responsive"> 
            </div>
            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                <img src="images/bdsoftlogo.png" class="img-responsive"> 
            </div>
            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                <img src="images/google.jpg" class="img-responsive"> 
            </div>
            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                <img src="images/youtube.png" class="img-responsive"> 
            </div>
            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                <img src="images/fb.png" class="img-responsive"> 
            </div>
            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                <img src="images/logo.png" class="img-responsive"> 
            </div>
            
        </div>
    </div>
  </section>



 <?php include'footer.php' ;?>