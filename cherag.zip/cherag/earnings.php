 <?php $page_heading = "Service Provider Profile";?>
 <?php include 'header.php' ;?>
<?php include 'service_provider_menu.php' ;?>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="earnings">
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
					<div class="short_info">
						<label class="switch">
					      <input class="switch-input" type="checkbox" />
					      <span class="switch-label" data-on="Online" data-off="Offline"></span> 
					      <span class="switch-handle"></span> 
					  	</label>
					  	<div class="user-icon">
					  		<img src="images/user-icon.png" class="center">
					  		<h2>Shahadat Hossain</h2>
					  		<p>Professional Website Designer</p>
					  	</div>
					  	<div class="sp_ratting">
					  		<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star checked"></span>
							<span class="fa fa-star"></span>
					  	</div>
					  	<h3 class="contact">CONTACT</h3>
					  	<hr class="hr-3px">

					  	<div class="sp_contact">
					  		<h4><i class="fa fa-map-marker" aria-hidden="true"></i> From : Dhaka</h4>
					  		<h4><i class="fa fa-user" aria-hidden="true"></i> Member Since : 2019</h4>
					  		<h4><i class="fa fa-clock-o" aria-hidden="true"></i> Response Time : 12 mins</h4>
					  	</div>


					</div>
				</div>
				<div class="col-md-8">
					<div class="earnings_details">
						<h2>Earnings</h2>

						<table width="100%" class="earnings_table">
							<thead>
								<tr>
									<th>Total</th>
									<th>Active </th>
									<th>Pending</th>
									<th>Pending Withdraw</th>
								</tr>
							</thead>
							<tr>
								<td>10000 BDT</td>
								<td>15000 BDT</td>
								<td>12000 BDT</td>
								<td>25900 BDT</td>
							</tr>
						</table>
					</div>
					<a href="" class="btn btn-default withdraw-btn">Withdraw</a>
					<a href="" class="btn btn-default">Payoneer</a>
					<a href="" class="btn btn-default">Bank Transfer</a>
				</div>
				<div style="clear: both;"></div>
			</div>
		</div>
	</div>
</div>

<?php include 'footer.php' ;?>