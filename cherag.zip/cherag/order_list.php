 <?php $page_heading = "Service Provider Profile";?>
 <?php include 'header.php' ;?>
<?php include 'service_provider_menu.php' ;?>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="earnings">
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
					<div class="orders_list">
						<ul>
							<li><a href="">All Orders (12345)</a> <i class="fa fa-angle-right"></i></li>
							<li><a href="">Active Orders (12345)</a></li>
							<li><a href="">Previous Orders (12345)</a></li>
							<li><a href="">Cancelled Orders (12345)</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-8">
					<div class="active_orders">

						<div class="active_orders_list">
							<div class="col-md-12">
								<div class="col-md-3 src-icon">
									<img src="images/service3.png" class="img-responsive" >
								</div>
								<div class="col-md-6 srvc-name-dtls">
									<h4>About the Service</h4>
									<p>Buyer Name: hjgh</p>
								</div>
								<div class="col-md-3 time-remaining">
									<p>2000 bdt</p>
									<p>7 hrs remaining</p>
								</div>
							</div>
							<div style="clear: both;"></div>
						</div>

						<div class="active_orders_list">
							<div class="col-md-12">
								<div class="col-md-3 src-icon">
									<img src="images/service3.png" class="img-responsive" >
								</div>
								<div class="col-md-6 srvc-name-dtls">
									<h4>About the Service</h4>
									<p>Buyer Name: hjgh</p>
								</div>
								<div class="col-md-3 time-remaining">
									<p>2000 bdt</p>
									<p>7 hrs remaining</p>
								</div>
							</div>
							<div style="clear: both;"></div>
						</div>

						<div class="active_orders_list">
							<div class="col-md-12">
								<div class="col-md-3 src-icon">
									<img src="images/service3.png" class="img-responsive" >
								</div>
								<div class="col-md-6 srvc-name-dtls">
									<h4>About the Service</h4>
									<p>Buyer Name: hjgh</p>
								</div>
								<div class="col-md-3 time-remaining">
									<p>2000 bdt</p>
									<p>7 hrs remaining</p>
								</div>
							</div>
							<div style="clear: both;"></div>
						</div>

						<div class="active_orders_list">
							<div class="col-md-12">
								<div class="col-md-3 src-icon">
									<img src="images/service3.png" class="img-responsive" >
								</div>
								<div class="col-md-6 srvc-name-dtls">
									<h4>About the Service</h4>
									<p>Buyer Name: hjgh</p>
								</div>
								<div class="col-md-3 time-remaining">
									<p>2000 bdt</p>
									<p>7 hrs remaining</p>
								</div>
							</div>
							<div style="clear: both;"></div>
						</div>

						<div class="active_orders_list">
							<div class="col-md-12">
								<div class="col-md-3 src-icon">
									<img src="images/service3.png" class="img-responsive" >
								</div>
								<div class="col-md-6 srvc-name-dtls">
									<h4>About the Service</h4>
									<p>Buyer Name: hjgh</p>
								</div>
								<div class="col-md-3 time-remaining">
									<p>2000 bdt</p>
									<p>7 hrs remaining</p>
								</div>
							</div>
							<div style="clear: both;"></div>
						</div>
					</div>
				</div>
				<div style="clear: both;"></div>
			</div>
		</div>
	</div>
</div>

<?php include 'footer.php' ;?>