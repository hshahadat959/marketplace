 <?php $page_heading = "Upload a service";?>
 <?php include 'header.php' ;?>
 <?php include 'service_provider_menu.php' ;?>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="order_no">
				<h2>Order #0157C46FG44</h2>
				<p>Buyer Name: johndoe01 | December 20, 2018</p>

				<table width="100%">
					<tr class="order_thead">
						<td style="padding-left: 15px;">Item</td>
						<td>Quantity</td>
						<td>Duration</td>
						<td>Amount</td>
					</tr>
					<tr style="    border-bottom: 2px solid;">
						<td style="padding-left: 15px;">
							<h4>Service Name</h4>
							<p>Service Description</p>
							<p>Service Description</p>
							<p>Service Description</p>
							<p>Service Description</p>
							<p>Service Description</p>
							<p>Service Description</p>
						</td>
						<td>1</td>
						<td>2 Days</td>
						<td>12000 BDT</td>
					</tr>
					<tr>
						<td colspan="2"></td>
						<td>Total amount</td>
						<td>1200 BDT</td>
					</tr>
				</table>
			</div>
		</div>
		<div class="col-md-12">
			<div class="clock">
				<table width="100%">
					<tr>
						<td class="clock_td">05</td>
						<td class="clock_td_sp">:</td>
						<td class="clock_td">12</td>
						<td class="clock_td_sp">:</td>
						<td class="clock_td">48</td>
						<td class="clock_td_sp">:</td>
						<td class="clock_td">36</td>
					</tr>
				</table>
			</div>
		</div>
		<div class="col-md-12">
			<div class="chat_in_order">
				<p style="text-align: center; font-size: 90px; margin-bottom: 0;"><i class="fa fa-handshake-o"></i></p>
				<h3 style="text-align: center; color: #adacb4; margin-top: 0;">Order Requirements</h3>
				<p class="chat_in_order_p" >Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of cl tin literature from 45 BC, making it over </p>

				<div class="main_chat">
					<div class="main_chat_scroll">
						<div class="chat-party-one">
							<h4><i class="fa fa-user-circle"></i> Shahadat Hossain</h4>
							<div class="chat-party-one_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div class="chat-party-two">
							<h4> Riyad Hossain <i class="fa fa-user-circle"></i></h4>
							<div class="chat-party-two_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div style="clear: both;"></div>
						<div class="chat-party-one">
							<h4><i class="fa fa-user-circle"></i> Shahadat Hossain</h4>
							<div class="chat-party-one_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div class="chat-party-two">
							<h4> Riyad Hossain <i class="fa fa-user-circle"></i></h4>
							<div class="chat-party-two_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div style="clear: both"></div>
						<div class="chat-party-one">
							<h4><i class="fa fa-user-circle"></i> Shahadat Hossain</h4>
							<div class="chat-party-one_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div class="chat-party-two">
							<h4> Riyad Hossain <i class="fa fa-user-circle"></i></h4>
							<div class="chat-party-two_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div style="clear: both;"></div>
						<div class="chat-party-one">
							<h4><i class="fa fa-user-circle"></i> Shahadat Hossain</h4>
							<div class="chat-party-one_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div class="chat-party-two">
							<h4> Riyad Hossain <i class="fa fa-user-circle"></i></h4>
							<div class="chat-party-two_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div style="clear: both"></div>
						<div class="chat-party-one">
							<h4><i class="fa fa-user-circle"></i> Shahadat Hossain</h4>
							<div class="chat-party-one_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div class="chat-party-two">
							<h4> Riyad Hossain <i class="fa fa-user-circle"></i></h4>
							<div class="chat-party-two_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div style="clear: both;"></div>
						<div class="chat-party-one">
							<h4><i class="fa fa-user-circle"></i> Shahadat Hossain</h4>
							<div class="chat-party-one_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div class="chat-party-two">
							<h4> Riyad Hossain <i class="fa fa-user-circle"></i></h4>
							<div class="chat-party-two_mgs">
								Contrary to popular belief
							</div>
						</div>
						<div style="clear: both"></div>
						</div>

					<div class="chat_input">
						<form class="example" action="">
						  <input type="text" placeholder="Write message here..." name="send">
						  <button type="submit">Send</button>
						</form>


					</div>
					<p class="emoticon"><i class="fa fa-smile-o"></i> &nbsp; <i class="fa fa-upload"></i></p>
					<div style="clear: both"></div>
				</div>

				
			</div>
		</div>
	</div>
</div>
<style type="text/css">


form.example input[type=text] {
    padding: 10px;
    font-size: 17px;
    float: left;
    width: 80%;
    background: #fff;
    border: none;
    border-radius: 5px 0px 0px 5px;
}

form.example button {
  float: left;
  width: 20%;
  padding: 10px;
  color: #5d5d5d;
  font-size: 17px;
  cursor: pointer;
  background: #fff;
  border: none;
  border-radius: 0px 5px 5px 0px;
  font-family: arboria-bold;
}
</style>
  <?php include 'footer.php' ;?>