<?php $page_heading = "Service Provider Profile";?>
<?php include 'header.php' ;?>
<img src="images/latest_deals_baner.jpg" class="img-responsive" width="100%">

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="latest_deals">
				<h1>Latest Deals</h1>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>

				<div class="ld_categories">
					<h3>Category One</h3>

					<div class="carousel slide media-carousel " id="action">
			            <div class="carousel-inner ">
			              <div class="item  active">
			                <div class="row">
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service1.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service2.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service3.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                       
			                  
			            
			                </div>
			              </div>
			              <div class="item">
			                <div class="row">
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service1.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service2.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service3.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>   
			                </div>
			              </div>
			            </div>
			            <a data-slide="prev" href="#action" class="left carousel-control">‹</a>
			            <a data-slide="next" href="#action" class="right carousel-control">›</a>
			          </div>
				</div>
			</div>

			<div class="ld_categories">
					<h3>Category Two</h3>

					<div class="carousel slide media-carousel " id="action1">
			            <div class="carousel-inner ">
			              <div class="item  active">
			                <div class="row">
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service1.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service2.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service3.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                       
			                  
			            
			                </div>
			              </div>
			              <div class="item">
			                <div class="row">
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service1.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service2.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service3.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>   
			                </div>
			              </div>
			            </div>
			            <a data-slide="prev" href="#action1" class="left carousel-control">‹</a>
			            <a data-slide="next" href="#action1" class="right carousel-control">›</a>
			          </div>
				</div>
			</div>

			<div class="ld_categories">
					<h3>Category Three</h3>

					<div class="carousel slide media-carousel " id="action2">
			            <div class="carousel-inner ">
			              <div class="item  active">
			                <div class="row">
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service1.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service2.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service3.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                       
			                  
			            
			                </div>
			              </div>
			              <div class="item">
			                <div class="row">
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service1.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service2.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service3.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>   
			                </div>
			              </div>
			            </div>
			            <a data-slide="prev" href="#action2" class="left carousel-control">‹</a>
			            <a data-slide="next" href="#action2" class="right carousel-control">›</a>
			          </div>
				</div>
			</div>

			<div class="ld_categories">
					<h3>Category Four</h3>

					<div class="carousel slide media-carousel " id="action3">
			            <div class="carousel-inner ">
			              <div class="item  active">
			                <div class="row">
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service1.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service2.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service3.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                       
			                  
			            
			                </div>
			              </div>
			              <div class="item">
			                <div class="row">
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service1.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service2.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>
			                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 poster">
			                    <center><a class="" href="#">
			                      <div class="service-logo">
			                        <img alt="" src="images/service3.png" class="service-img">
			                        <div class="overlay">
			                            <div class="text">Service Description</div>
			                        </div>
			                      </div>
			                    </a></center>
			                  </div>   
			                </div>
			              </div>
			            </div>
			            <a data-slide="prev" href="#action3" class="left carousel-control">‹</a>
			            <a data-slide="next" href="#action3" class="right carousel-control">›</a>
			          </div>
				</div>
			</div>
		</div>
	</div>
</div>

<style type="text/css">
	.media-carousel .carousel-control.left{
		margin-top: 12%;
	}
</style>
<?php include 'footer.php' ;?>