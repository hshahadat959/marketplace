 <?php $page_heading = "Upload a service";?>
 <?php include 'header.php' ;?>
 <?php include 'service_provider_menu.php' ;?>

<section class="services">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="search_criteria col-md-3" style="padding-left: 0px;">
					<a href="" class=" btn btn-default search_criteria_btn"><i class="fa fa-map-marker"></i> Select location</a>
				</div>
				<div class="search_criteria col-md-3">
					<a href="" class=" btn btn-default search_criteria_btn"><i class="fa fa-filter"></i> Select Category</a>
				</div>
				<div class="search_criteria col-md-6" style="padding-right: 0px;">
					<form action="">
						<input type="text" name="search" placeholder="What are you looking for?" class="form-control search">
					</form>
					
					<!-- <a href="" class=" btn btn-default search_criteria_btn"> What are you looking for? <i class="fa fa-search"></i></a> -->
				</div>
			</div>
			<div class="col-md-12" style="margin-top: 30px;">
				<div class="col-md-3 no-padding">
					<div class="search_with">
						<h4>Short result</h4>
						<hr class="show_results_hr">
						<input type="text" name="Category" class="category form-control">
						<h4 class="category">Category</h4>
						<h4 class="all_classes">All Classes</h4>
						<ul>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
							<li>Name Here (67,547)</li>
						</ul>
						<h4>Locations</h4>
						<hr class="show_results_hr">
						<ul>
							<li>Dhaka (67,547)</li>
							<li>Chittagong (67,547)</li>
							<li>Khulna (67,547)</li>
							<li>Sylhet (67,547)</li>
							<li>Barisal (67,547)</li>
							
						</ul>
					</div>
				</div>
				<div class="col-md-9 no-padding">
					<div class="search_result">
						<h4>All Postings in Bangladesh...</h4>
						<p>Showing 1-25 of 3,154,789 results</p>

						<div class="service_list">
							<div class="col-md-4">
								<img src="images/service1.png" class="img-responsive service_img">
							</div>
							<div class="col-md-8 service_details">
									<h4>Packaging Design</h4>
									<p>Some text..Some text..Some text..Some text..Some text..Some text..Some text..Some text..</p>
									<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
							</div>
							<div style="clear: both;"></div>
						</div>
						<div class="service_list">
							<div class="col-md-4">
								<img src="images/service2.png" class="img-responsive service_img">
							</div>
							<div class="col-md-8 service_details">
									<h4>Packaging Design</h4>
									<p>Some text..Some text..Some text..Some text..Some text..Some text..Some text..Some text..</p>
									<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
							</div>
							<div style="clear: both;"></div>
						</div>
						<div class="service_list">
							<div class="col-md-4">
								<img src="images/service3.png" class="img-responsive service_img">
							</div>
							<div class="col-md-8 service_details">
									<h4>Packaging Design</h4>
									<p>Some text..Some text..Some text..Some text..Some text..Some text..Some text..Some text..</p>
									<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
							</div>
							<div style="clear: both;"></div>
						</div>
						<div class="service_list">
							<div class="col-md-4">
								<img src="images/service4.png" class="img-responsive service_img">
							</div>
							<div class="col-md-8 service_details">
									<h4>Packaging Design</h4>
									<p>Some text..Some text..Some text..Some text..Some text..Some text..Some text..Some text..</p>
									<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
							</div>
							<div style="clear: both;"></div>
						</div>
						<div class="service_list">
							<div class="col-md-4">
								<img src="images/service5.png" class="img-responsive service_img">
							</div>
							<div class="col-md-8 service_details">
									<h4>Packaging Design</h4>
									<p>Some text..Some text..Some text..Some text..Some text..Some text..Some text..Some text..</p>
									<p><i class="fa fa-clock-o" aria-hidden="true"></i> Within 2 hours</p>
							</div>
							<div style="clear: both;"></div>
						</div>
						<ul class="pagination">
						    <li><a href="#">1</a></li>
						    <li class="active"><a href="#">2</a></li>
						    <li><a href="#">3</a></li>
						    <li><a href="#">4</a></li>
						    <li><a href="#">5</a></li>
						</ul>
					</div>
				</div>
				
			</div>
		</div>
	</div>
</section>

 <?php include 'footer.php' ;?> 